/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.runapplication;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class IRoadsConstructedTest {
    
    public IRoadsConstructedTest() {
    }

    /**
     * Test of getCity method, of class IRoadsConstructed.
     */
    @Test
    public void testGetCity() {
    }

    /**
     * Test of getTotalRoadsConstructed method, of class IRoadsConstructed.
     */
    @Test
    public void testGetTotalRoadsConstructed() {
    }

    public class IRoadsConstructedImpl implements IRoadsConstructed {

        public String getCity() {
            return "";
        }

        public int getTotalRoadsConstructed() {
            return 0;
        }
    }
    
}
