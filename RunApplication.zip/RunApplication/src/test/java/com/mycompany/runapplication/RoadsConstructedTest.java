/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.runapplication;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class RoadsConstructedTest {
    
    public RoadsConstructedTest() {
    }

    /**
     * Test of getCity method, of class RoadsConstructed.
     */
    @Test
    public void testGetCity() {
    }

    /**
     * Test of getTotalRoadsConstructed method, of class RoadsConstructed.
     */
    @Test
    public void testGetTotalRoadsConstructed() {
    }

    public class RoadsConstructedImpl extends RoadsConstructed {

        public RoadsConstructedImpl() {
            super("", 0);
        }
    }
    
}
