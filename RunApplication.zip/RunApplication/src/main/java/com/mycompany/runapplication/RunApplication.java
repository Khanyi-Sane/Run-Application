/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.runapplication;
import java.util.Scanner;


/**
 *
 * @author Student
 */
// Interface defines methods that must be implemented
interface IRoadsConstructed {
    String getCity();
    int getTotalRoadsConstructed();
}

// Abstract class implements the interface
// It  will store shared data for subclasses
abstract class RoadsConstructed implements IRoadsConstructed {

    private String city;
    private int totalRoadsConstructed;

    // Constructor to initialise values
    public RoadsConstructed(String city, int totalRoadsConstructed) {
        this.city = city;
        this.totalRoadsConstructed = totalRoadsConstructed;
    }

    public String getCity() {
        return city;
    }

    public int getTotalRoadsConstructed() {
        return totalRoadsConstructed;
    }
}

// Subclass that extends abstract class
class RoadConstructionReport extends RoadsConstructed {

    public RoadConstructionReport(String city, int totalRoadsConstructed) {
        super(city, totalRoadsConstructed);
    }

    public void printReport() {
        System.out.println("\nROAD CONSTRUCTION REPORT");
        System.out.println("------------------------");
        System.out.println("City: " + getCity());
        System.out.println("Total Roads Constructed: " + getTotalRoadsConstructed());
    }
}

// Main class where program runs
public class RunApplication {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter city: ");
        String city = input.nextLine();

        System.out.print("Enter total roads constructed: ");
        int roads = input.nextInt();

        RoadConstructionReport report = new RoadConstructionReport(city, roads);
        report.printReport();

        input.close();
    }
}